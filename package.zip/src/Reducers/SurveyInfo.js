const iState={
    title:"yoyo",
    description:"asds",
    project:"",
    duration:{start:"01/01/2020", end:"01/02/2022"},
    logo:"",
    showProgress:false,
    showQuestions:false
}


function SurveyInfo(state={iState}, action){
    switch(action.type){
        case "ADDINFO":
           return {
               ...state ,[action.payload.name]:action.payload.value
        };
        default:
            return state;
    }
}

export default SurveyInfo;
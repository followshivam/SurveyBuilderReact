// const iState={
    
// }

// function SurveyInfo(state={iState}, action){
//     switch(action.type){
//         case "ADDINFO":
//            return {
//                ...state ,[action.payload.name]:action.payload.value
//            };
//         default:
//             return state;
//     }
// }

// export default SurveyInfo;
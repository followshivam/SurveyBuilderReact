import React from 'react';
import './components.css';

function MainHeader() {
    return (
        <div className="mainHeader">
            <div className="main">
             <p>@ibps </p>
            </div>

            <a> MDM </a>
            <a> Process Designer</a>
            <a> Vamsi </a>
        </div>
    )
}

export default MainHeader

import React from 'react';
import '../App.css';

function ProjectTree() {
    return (
        <div className="projectTree">
            Project Tree ⚙
        </div>
    )
}

export default ProjectTree

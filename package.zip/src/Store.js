import {createStore} from "redux";
import SurveyInfo from "./Reducers/SurveyInfo" 


export const store=createStore(
    SurveyInfo, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

export default store;
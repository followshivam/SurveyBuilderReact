function addInfo(data){
    return{
        type:"ADDINFO",
        payload:data
    }
}

export {addInfo};
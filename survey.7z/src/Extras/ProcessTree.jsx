import React from 'react'

function ProcessTree() {
    return (
        <div className="processTree">
            Process Tree ⚙
        </div>
    )
}

export default ProcessTree
